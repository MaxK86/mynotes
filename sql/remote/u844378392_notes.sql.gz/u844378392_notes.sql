
-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 15 2015 г., 11:16
-- Версия сервера: 10.0.11-MariaDB
-- Версия PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `u844378392_notes`
--

-- --------------------------------------------------------

--
-- Структура таблицы `affairs`
--

CREATE TABLE IF NOT EXISTS `affairs` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `dateDue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `complete` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id_new` (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='main table' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `bookmarks`
--

CREATE TABLE IF NOT EXISTS `bookmarks` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `link` tinytext,
  `folder_id` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `id_entity` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id_folders` (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories_refs`
--

CREATE TABLE IF NOT EXISTS `categories_refs` (
  `id_category` int(4) DEFAULT NULL,
  `parent_id` int(4) DEFAULT NULL,
  `id_entity` int(4) DEFAULT NULL,
  `type` varchar(128) DEFAULT NULL,
  UNIQUE KEY `categories_refs_idx1` (`id_entity`,`type`),
  KEY `categories_refs_idx2` (`id_category`),
  KEY `categories_refs_idx3` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0;

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `desc` text,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id_category` (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `credentials`
--

CREATE TABLE IF NOT EXISTS `credentials` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `password` tinytext,
  `key_id` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_file` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='main table' AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `notes`
--

INSERT INTO `notes` (`id`, `body`, `created`, `id_file`) VALUES
(1, '1. Добавления пользователя в группу\r\nsudo adduser username groupname', '2015-07-14 20:34:05', NULL),
(3, 'Pull - тянуть\r\nFetch - выбирать', '2015-07-14 12:11:49', NULL),
(4, 'Команда для получения дерева измененных файлов в диапазоне коммитов. Диапазон обязательно указать снизу вверх (SHA)\r\n\r\ngit diff-tree -r --no-commit-id --name-only \r\n31122abb94baa8d0a17466f665602b763d10a9f4^..\r\n7b8690498a8f27e4e423b93140f3a7d23d246e42 | \r\nxargs tar -rf /home/max/tmp/vm-git10.02-22.05.tar', '2015-07-14 12:15:50', NULL),
(5, 'Создание бекапа с указанием его даты и архивацией\r\nmysqldump -u root -proot mynotes --default-character-set=utf8 | gzip > `date +./mynotes.sql.%Y%m%d.%H%M%S.gz`', '2015-07-14 14:09:13', NULL),
(8, 'Крутой гол месси 49 сек\r\nhttps://www.youtube.com/watch?v=898GLNNJd48\r\n', '2015-07-14 21:48:31', NULL),
(7, 'Тулзя для изменения групп пользователей\r\nsudo apt-get install gnome-system-tools', '2015-07-14 20:33:56', NULL),
(9, 'Распаковать архив в БД\r\nzcat u844378392_notes.sql.gz | mysql -u root -proot mynotes', '2015-07-14 22:46:54', NULL),
(10, 'Разделы приложения\r\nЗаметки, Закладки, Пароли, Дела,  , timetracker, Синхронихация Данных по REST API!!!', '2015-07-15 10:47:02', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
